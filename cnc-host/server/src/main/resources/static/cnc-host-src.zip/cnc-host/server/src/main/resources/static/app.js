/* CNC 服务端管理后台（无构建链，原生 JS） */
(() => {
  "use strict";

  const S = {
    token: localStorage.getItem("cnc_token") || "",
    config: null,
    tasks: [],
    devices: [],
    status: null,
    tab: "overview",
    ws: null
  };

  const $ = (id) => document.getElementById(id);
  const esc = (v) => String(v == null ? "" : v)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  const jsStr = (v) => String(v == null ? "" : v).replace(/\\/g, "\\\\").replace(/'/g, "\\'");

  // ===== API =====
  async function api(path, opts = {}) {
    const headers = Object.assign({ Authorization: "Bearer " + S.token }, opts.headers || {});
    let body = opts.body;
    if (body != null && typeof body !== "string") {
      body = JSON.stringify(body);
      headers["Content-Type"] = "application/json";
    }
    const res = await fetch(path, Object.assign({}, opts, { body, headers }));
    if (res.status === 401) {
      logout("管理口令无效或已变更，请重新登录");
      throw new Error("未授权");
    }
    const data = await res.json().catch(() => null);
    if (!res.ok) throw new Error((data && data.message) || ("HTTP " + res.status));
    return data;
  }

  function toast(msg, isError) {
    const t = $("toast");
    t.textContent = msg;
    t.className = "toast show" + (isError ? " error" : "");
    clearTimeout(t._timer);
    t._timer = setTimeout(() => { t.className = "toast"; }, 3200);
  }

  // ===== 登录 =====
  async function login() {
    const token = $("token").value.trim();
    if (!token) { $("login-error").textContent = "请输入管理口令"; return; }
    S.token = token;
    try {
      await api("/api/v1/auth/check");
      localStorage.setItem("cnc_token", token);
      $("login").style.display = "none";
      $("app").style.display = "block";
      await loadAll();
      connectWs();
    } catch (e) {
      if (e.message !== "未授权") $("login-error").textContent = e.message;
    }
  }

  function logout(msg) {
    localStorage.removeItem("cnc_token");
    S.token = "";
    if (S.ws) { try { S.ws.close(); } catch (_) {} S.ws = null; }
    $("app").style.display = "none";
    $("login").style.display = "flex";
    $("login-error").textContent = msg || "";
    $("token").value = "";
  }

  // ===== 数据 =====
  async function loadAll() {
    S.config = await api("/api/v1/config");
    S.tasks = await api("/api/v1/tasks");
    S.devices = await api("/api/v1/devices").catch(() => []);
    $("cfg-version").textContent = S.config.version;
    renderNav();
    render();
  }

  function findById(list, id) {
    return (list || []).find((x) => x.id === id);
  }
  function correctionOf(drawingId) {
    return (S.config.drawingCorrections || []).find((c) => c.drawingId === drawingId);
  }
  function optionList(list, valueKey, labelFn, selected) {
    return list.map((x) => {
      const v = x[valueKey];
      const sel = String(v) === String(selected) ? " selected" : "";
      return `<option value="${esc(v)}"${sel}>${esc(labelFn(x))}</option>`;
    }).join("");
  }

  // ===== 导航 =====
  const TABS = [
    { id: "overview", label: "概览", sub: "配置版本与设备实时状态" },
    { id: "device", label: "设备与通讯", sub: "控制卡、行程与网络/串口参数" },
    { id: "tools", label: "刀具库", sub: "刀具编号、类型与磨损状态", count: (c) => c.tools.length },
    { id: "materials", label: "材料库", sub: "切削速度、进给与切深推荐值", count: (c) => c.materials.length },
    { id: "parts", label: "零件与毛坯", sub: "零件、毛坯尺寸与装夹方式", count: (c) => c.parts.length + c.blanks.length },
    { id: "plans", label: "工艺方案", sub: "工序步骤与切削参数", count: (c) => c.plans.length },
    { id: "drawings", label: "图纸任务", sub: "DXF 原文与尺寸校正，客户端据此生成刀路", count: (c) => c.drawings.length },
    { id: "devices", label: "设备管理", sub: "注册设备、在线状态与功能权限", count: () => S.devices.length },
    { id: "tasks", label: "任务记录", sub: "平板端回传的执行记录", count: () => S.tasks.length }
  ];

  function renderNav() {
    $("nav").innerHTML = TABS.map((t) => {
      const n = t.count ? t.count(S.config) : "";
      return `<div class="nav-item ${S.tab === t.id ? "active" : ""}" onclick="switchTab('${t.id}')">
        <span>${esc(t.label)}</span><span class="count">${n}</span></div>`;
    }).join("");
  }

  window.switchTab = function (id) {
    S.tab = id;
    renderNav();
    render();
  };

  function render() {
    const t = TABS.find((x) => x.id === S.tab);
    $("page-title").textContent = t.label;
    $("page-sub").textContent = t.sub;
    const c = S.config;
    const views = {
      overview: viewOverview,
      device: viewDevice,
      tools: viewTools,
      materials: viewMaterials,
      parts: viewParts,
      plans: viewPlans,
      drawings: viewDrawings,
      devices: viewDevices,
      tasks: viewTasks
    };
    $("content").innerHTML = views[S.tab](c);
  }

  // ===== 概览 =====
  function liveStatusHtml() {
    const s = S.status || {};
    const connected = !!s.connected;
    return `
      <div class="live-grid">
        <div class="live-item"><div class="k">平板连接</div><div class="v">${connected ? "在线" : "离线"}</div></div>
        <div class="live-item"><div class="k">运行模式</div><div class="v">${esc(s.mode || "-")}${s.isSimulated ? "（模拟）" : ""}</div></div>
        <div class="live-item"><div class="k">当前任务</div><div class="v">${esc(s.taskName || "无")}</div></div>
        <div class="live-item"><div class="k">任务进度</div><div class="v">${Math.round((s.progress || 0) * 100)}%</div></div>
        <div class="live-item"><div class="k">X / Z 位置</div><div class="v">${s.xMm == null ? "-" : Number(s.xMm).toFixed(2)} / ${s.zMm == null ? "-" : Number(s.zMm).toFixed(2)}</div></div>
        <div class="live-item"><div class="k">主轴</div><div class="v">${s.spindleRpm == null ? "-" : s.spindleRpm + " rpm"}</div></div>
      </div>
      <div class="desc" style="margin-top:12px">${esc(s.message || "暂无状态上报")} · ${s.timestamp ? new Date(s.timestamp).toLocaleString() : "-"}</div>`;
  }

  function viewOverview(c) {
    const active = (S.tasks || []).filter((t) => t.status === "SUCCESS").length;
    return `
      <div class="cards">
        <div class="card"><div class="k">配置版本</div><div class="v">v${c.version}</div><div class="hint">任何配置写入 +1</div></div>
        <div class="card"><div class="k">图纸任务</div><div class="v">${c.drawings.length}</div><div class="hint">可下发到平板</div></div>
        <div class="card"><div class="k">工艺方案</div><div class="v">${c.plans.length}</div><div class="hint">共 ${c.plans.reduce((n, p) => n + (p.steps || []).length, 0)} 道工序</div></div>
        <div class="card"><div class="k">累计完成</div><div class="v">${active}</div><div class="hint">成功任务记录</div></div>
      </div>
      <div class="hint-box">平板客户端只负责选任务、预览、下发和监控；参数全部在此维护。客户端离线时使用上次同步缓存，联网后以服务端版本为准覆盖。</div>
      <div class="panel"><h3>设备实时状态</h3><div id="live-area">${liveStatusHtml()}</div></div>
      <div class="panel"><h3>最近任务</h3>${taskTable(S.tasks.slice(0, 6))}</div>`;
  }

  // ===== 设备 =====
  function viewDevice(c) {
    const d = c.device;
    const comm = d.comm || {};
    return `
      <div class="hint-box">设备与通讯参数由服务端统一下发。修改后需在平板「高级 → 服务端同步」点一次同步；急停、限位与运动下发不依赖服务端在线。</div>
      <div class="panel">
        <h3>控制卡与行程
          <button class="primary small" onclick="saveDevice()">保存</button>
        </h3>
        <div class="form-row">
          <div class="field"><label>设备名称</label><input id="dev_name" value="${esc(d.name)}"></div>
          <div class="field"><label>控制卡</label><select id="dev_card">${optionList(
            ["FANUC_0I", "SIEMENS_840D", "MAZAK_SMART", "HASS_VF", "MODBUS_GENERIC"].map((v) => ({ v })), "v", (x) => x.v.replace(/_/g, " "), d.controlCard)}</select></div>
        </div>
        <div class="grid3">
          <div class="field"><label>X 最大行程 (mm)</label><input id="dev_tx" type="number" step="0.1" value="${esc(d.maxTravelXmm)}"></div>
          <div class="field"><label>Z 最大行程 (mm)</label><input id="dev_tz" type="number" step="0.1" value="${esc(d.maxTravelZmm)}"></div>
          <div class="field"><label>主轴最高转速 (rpm)</label><input id="dev_rpm" type="number" value="${esc(d.maxRpm)}"></div>
        </div>
        <div class="form-row" style="margin-top:12px">
          <div class="field"><label>最大进给 (mm/min)</label><input id="dev_feed" type="number" step="0.1" value="${esc(d.maxFeedMmPerMin)}"></div>
          <div class="field"><label class="check" style="margin-top:20px"><input type="checkbox" id="dev_sim" ${d.useSimulator ? "checked" : ""}> 使用模拟器（无真实控制卡时保持开启）</label></div>
        </div>
      </div>
      <div class="panel">
        <h3>通讯参数</h3>
        <div class="form-row">
          <div class="field"><label>协议</label><select id="comm_proto">${optionList(
            ["MODBUS_TCP", "MODBUS_RTU", "SERIAL_TCP"].map((v) => ({ v })), "v", (x) => x.v.replace(/_/g, " "), comm.protocol)}</select></div>
          <div class="field"><label>设备站号</label><input id="comm_dev" type="number" value="${esc(comm.deviceId)}"></div>
        </div>
        <div class="grid3">
          <div class="field"><label>IP 地址</label><input id="comm_ip" value="${esc(comm.ipAddress)}"></div>
          <div class="field"><label>端口</label><input id="comm_port" type="number" value="${esc(comm.port)}"></div>
          <div class="field"><label>超时 (ms)</label><input id="comm_timeout" type="number" value="${esc(comm.timeoutMs)}"></div>
        </div>
        <div class="grid2" style="margin-top:12px">
          <div class="field"><label>串口设备</label><input id="comm_serial" value="${esc(comm.serialPort)}"></div>
          <div class="field"><label>波特率</label><select id="comm_baud">${optionList(
            [9600, 19200, 38400, 57600, 115200].map((v) => ({ v })), "v", (x) => String(x.v), comm.baudRate)}</select></div>
        </div>
      </div>`;
  }

  window.saveDevice = async function () {
    const c = S.config;
    const d = {
      name: $("dev_name").value.trim(),
      controlCard: $("dev_card").value,
      useSimulator: $("dev_sim").checked,
      maxTravelXmm: Number($("dev_tx").value),
      maxTravelZmm: Number($("dev_tz").value),
      maxRpm: Number($("dev_rpm").value),
      maxFeedMmPerMin: Number($("dev_feed").value),
      comm: {
        protocol: $("comm_proto").value,
        ipAddress: $("comm_ip").value.trim(),
        port: Number($("comm_port").value),
        serialPort: $("comm_serial").value.trim(),
        baudRate: Number($("comm_baud").value),
        deviceId: Number($("comm_dev").value),
        timeoutMs: Number($("comm_timeout").value)
      }
    };
    try {
      await api("/api/v1/device", { method: "PUT", body: d });
      toast("设备与通讯配置已保存");
      await loadAll();
    } catch (e) { toast(e.message, true); }
  };

  // ===== 通用表格 =====
  function table(headers, rows, emptyText) {
    if (!rows.length) return `<div class="empty">${esc(emptyText || "暂无数据")}</div>`;
    return `<table><thead><tr>${headers.map((h) => `<th>${esc(h)}</th>`).join("")}</tr></thead>
      <tbody>${rows.join("")}</tbody></table>`;
  }

  function tag(v, on) {
    return `<span class="tag ${on ? "on" : "off"}">${esc(v)}</span>`;
  }

  // ===== 刀具 =====
  function viewTools(c) {
    const rows = c.tools.map((t) => `<tr>
      <td>${t.toolNumber}</td>
      <td>${esc(t.name)}</td>
      <td class="mono">${esc(t.toolType)}</td>
      <td>${esc(t.material)}</td>
      <td>${t.maxRpm} rpm / ${t.maxFeedMmPerMin} mm/min</td>
      <td>${tag(t.wearStatus, t.wearStatus === "NEW")}</td>
      <td class="muted">${t.usageCount} 次</td>
      <td class="actions"><button class="small" onclick="openTool('${jsStr(t.id)}')">编辑</button>
        <button class="small danger" onclick="delEntity('tools','${jsStr(t.id)}','刀具')">删除</button></td>
    </tr>`);
    return `<div class="panel"><h3>刀具库 <button class="primary small" onclick="openTool('')">新增刀具</button></h3>
      ${table(["T#", "名称", "类型", "材质", "能力", "磨损", "使用", ""], rows, "尚未配置刀具")}</div>`;
  }

  const TOOL_TYPES = ["TURNING", "FINISH_TURNING", "GROOVING", "THREADING", "DRILLING", "CUT_OFF"];
  const WEAR = ["NEW", "LIGHT", "MODERATE", "CRITICAL"];

  window.openTool = function (id) {
    const t = findById(S.config.tools, id) || { toolNumber: 1, toolType: "TURNING", name: "", material: "CARBIDE", nominalDiameterMm: 0, lengthMm: 0, maxRpm: 3000, maxFeedMmPerMin: 500, wearStatus: "NEW", usageCount: 0, notes: "" };
    openModal(id ? "编辑刀具" : "新增刀具", `
      <div class="form-row">
        <div class="field"><label>刀具号 T</label><input id="f_toolNumber" type="number" value="${esc(t.toolNumber)}"></div>
        <div class="field"><label>名称</label><input id="f_name" value="${esc(t.name)}"></div>
      </div>
      <div class="form-row">
        <div class="field"><label>类型</label><select id="f_toolType">${optionList(TOOL_TYPES.map((v) => ({ v })), "v", (x) => x.v, t.toolType)}</select></div>
        <div class="field"><label>刀体材质</label><select id="f_material">${optionList(["HSS", "CARBIDE", "CERAMIC"].map((v) => ({ v })), "v", (x) => x.v, t.material)}</select></div>
        <div class="field"><label>磨损状态</label><select id="f_wearStatus">${optionList(WEAR.map((v) => ({ v })), "v", (x) => x.v, t.wearStatus)}</select></div>
      </div>
      <div class="grid3">
        <div class="field"><label>刀尖直径 (mm)</label><input id="f_nominalDiameterMm" type="number" step="0.1" value="${esc(t.nominalDiameterMm)}"></div>
        <div class="field"><label>有效长度 (mm)</label><input id="f_lengthMm" type="number" step="0.1" value="${esc(t.lengthMm)}"></div>
        <div class="field"><label>使用次数</label><input id="f_usageCount" type="number" value="${esc(t.usageCount)}"></div>
      </div>
      <div class="grid2" style="margin-top:12px">
        <div class="field"><label>最高转速 (rpm)</label><input id="f_maxRpm" type="number" value="${esc(t.maxRpm)}"></div>
        <div class="field"><label>最大进给 (mm/min)</label><input id="f_maxFeedMmPerMin" type="number" step="0.1" value="${esc(t.maxFeedMmPerMin)}"></div>
      </div>
      <div class="field" style="margin-top:12px"><label>备注</label><textarea id="f_notes" rows="2">${esc(t.notes)}</textarea></div>`,
      async () => {
        const body = {
          id: id || "",
          toolNumber: Number($("f_toolNumber").value),
          toolType: $("f_toolType").value,
          name: $("f_name").value.trim(),
          material: $("f_material").value,
          nominalDiameterMm: Number($("f_nominalDiameterMm").value),
          lengthMm: Number($("f_lengthMm").value),
          maxRpm: Number($("f_maxRpm").value),
          maxFeedMmPerMin: Number($("f_maxFeedMmPerMin").value),
          wearStatus: $("f_wearStatus").value,
          usageCount: Number($("f_usageCount").value),
          notes: $("f_notes").value
        };
        await api("/api/v1/tools", { method: "POST", body });
        toast("刀具已保存");
      });
  };

  // ===== 材料 =====
  function viewMaterials(c) {
    const rows = c.materials.map((m) => `<tr>
      <td>${esc(m.name)}</td><td class="mono">${esc(m.code)}</td>
      <td>${m.density}</td><td>${esc(m.hardness)}</td>
      <td>${m.recommendedCuttingSpeedMs} m/min</td>
      <td>${m.recommendedFeedPerRev} mm/r</td>
      <td>${m.recommendedDepthMm} mm</td>
      <td>${tag(m.enabled ? "启用" : "停用", m.enabled)}</td>
      <td class="actions"><button class="small" onclick="openMaterial('${jsStr(m.id)}')">编辑</button>
        <button class="small danger" onclick="delEntity('materials','${jsStr(m.id)}','材料')">删除</button></td>
    </tr>`);
    return `<div class="panel"><h3>材料库 <button class="primary small" onclick="openMaterial('')">新增材料</button></h3>
      ${table(["名称", "牌号", "密度", "硬度", "切削速度", "每转进给", "切深", "状态", ""], rows, "尚未配置材料")}</div>`;
  }

  window.openMaterial = function (id) {
    const m = findById(S.config.materials, id) || { name: "", code: "", density: 7.85, hardness: "", recommendedCuttingSpeedMs: 150, recommendedFeedPerRev: 0.2, recommendedDepthMm: 2, enabled: true, notes: "" };
    openModal(id ? "编辑材料" : "新增材料", `
      <div class="form-row">
        <div class="field"><label>名称</label><input id="f_name" value="${esc(m.name)}"></div>
        <div class="field"><label>牌号</label><input id="f_code" value="${esc(m.code)}"></div>
      </div>
      <div class="grid3">
        <div class="field"><label>密度 (g/cm³)</label><input id="f_density" type="number" step="0.01" value="${esc(m.density)}"></div>
        <div class="field"><label>硬度</label><input id="f_hardness" value="${esc(m.hardness)}"></div>
        <div class="field"><label>推荐切削速度 (m/min)</label><input id="f_cs" type="number" step="0.1" value="${esc(m.recommendedCuttingSpeedMs)}"></div>
      </div>
      <div class="grid3" style="margin-top:12px">
        <div class="field"><label>每转进给 (mm/r)</label><input id="f_fr" type="number" step="0.01" value="${esc(m.recommendedFeedPerRev)}"></div>
        <div class="field"><label>推荐切深 (mm)</label><input id="f_depth" type="number" step="0.1" value="${esc(m.recommendedDepthMm)}"></div>
        <div class="field"><label class="check" style="margin-top:20px"><input type="checkbox" id="f_enabled" ${m.enabled ? "checked" : ""}> 启用</label></div>
      </div>
      <div class="field" style="margin-top:12px"><label>备注</label><textarea id="f_notes" rows="2">${esc(m.notes)}</textarea></div>`,
      async () => {
        const body = {
          id: id || "",
          name: $("f_name").value.trim(),
          code: $("f_code").value.trim(),
          density: Number($("f_density").value),
          hardness: $("f_hardness").value.trim(),
          recommendedCuttingSpeedMs: Number($("f_cs").value),
          recommendedFeedPerRev: Number($("f_fr").value),
          recommendedDepthMm: Number($("f_depth").value),
          enabled: $("f_enabled").checked,
          notes: $("f_notes").value
        };
        await api("/api/v1/materials", { method: "POST", body });
        toast("材料已保存");
      });
  };

  // ===== 零件与毛坯 =====
  function viewParts(c) {
    const partRows = c.parts.map((p) => `<tr>
      <td>${esc(p.name)}</td>
      <td>${esc((findById(c.materials, p.materialId) || {}).name || p.materialId)}</td>
      <td class="muted">${esc(p.notes)}</td>
      <td class="actions"><button class="small" onclick="openPart('${jsStr(p.id)}')">编辑</button>
        <button class="small danger" onclick="delEntity('parts','${jsStr(p.id)}','零件')">删除</button></td>
    </tr>`);
    const blankRows = c.blanks.map((b) => `<tr>
      <td>${esc((findById(c.parts, b.partId) || {}).name || b.partId)}</td>
      <td>φ${b.diameterMm} × ${b.lengthMm} mm</td>
      <td>${esc((findById(c.materials, b.materialId) || {}).name || b.materialId)}</td>
      <td>${esc(b.clampType)}</td>
      <td class="actions"><button class="small" onclick="openBlank('${jsStr(b.id)}')">编辑</button>
        <button class="small danger" onclick="delEntity('blanks','${jsStr(b.id)}','毛坯')">删除</button></td>
    </tr>`);
    return `
      <div class="panel"><h3>零件 <button class="primary small" onclick="openPart('')">新增零件</button></h3>
        ${table(["名称", "材料", "备注", ""], partRows, "尚未配置零件")}</div>
      <div class="panel"><h3>毛坯 <button class="primary small" onclick="openBlank('')">新增毛坯</button></h3>
        ${table(["所属零件", "尺寸", "材料", "装夹", ""], blankRows, "尚未配置毛坯")}</div>`;
  }

  window.openPart = function (id) {
    const p = findById(S.config.parts, id) || { name: "", materialId: (S.config.materials[0] || {}).id || "", notes: "" };
    openModal(id ? "编辑零件" : "新增零件", `
      <div class="form-row">
        <div class="field"><label>零件名称</label><input id="f_name" value="${esc(p.name)}"></div>
        <div class="field"><label>材料</label><select id="f_materialId">${optionList(S.config.materials, "id", (m) => m.name, p.materialId)}</select></div>
      </div>
      <div class="field"><label>备注</label><textarea id="f_notes" rows="2">${esc(p.notes)}</textarea></div>`,
      async () => {
        await api("/api/v1/parts", { method: "POST", body: { id: id || "", name: $("f_name").value.trim(), materialId: $("f_materialId").value, notes: $("f_notes").value } });
        toast("零件已保存");
      });
  };

  window.openBlank = function (id) {
    const b = findById(S.config.blanks, id) || { partId: (S.config.parts[0] || {}).id || "", diameterMm: 80, lengthMm: 120, materialId: (S.config.materials[0] || {}).id || "", clampType: "CHUCK" };
    openModal(id ? "编辑毛坯" : "新增毛坯", `
      <div class="form-row">
        <div class="field"><label>所属零件</label><select id="f_partId">${optionList(S.config.parts, "id", (p) => p.name, b.partId)}</select></div>
        <div class="field"><label>材料</label><select id="f_materialId">${optionList(S.config.materials, "id", (m) => m.name, b.materialId)}</select></div>
      </div>
      <div class="grid3">
        <div class="field"><label>直径 (mm)</label><input id="f_diameterMm" type="number" step="0.1" value="${esc(b.diameterMm)}"></div>
        <div class="field"><label>长度 (mm)</label><input id="f_lengthMm" type="number" step="0.1" value="${esc(b.lengthMm)}"></div>
        <div class="field"><label>装夹方式</label><select id="f_clampType">${optionList(["CHUCK", "COLLET", "CENTER"].map((v) => ({ v })), "v", (x) => x.v, b.clampType)}</select></div>
      </div>`,
      async () => {
        await api("/api/v1/blanks", { method: "POST", body: {
          id: id || "", partId: $("f_partId").value, diameterMm: Number($("f_diameterMm").value),
          lengthMm: Number($("f_lengthMm").value), materialId: $("f_materialId").value, clampType: $("f_clampType").value
        } });
        toast("毛坯已保存");
      });
  };

  // ===== 工艺方案 =====
  const STEP_TYPES = ["ROUGH_TURNING", "FINISH_TURNING", "GROOVING", "THREADING", "DRILLING", "CUT_OFF"];

  function stepRow(s, tools, idx) {
    return `<tr data-step="${idx}">
      <td>${idx + 1}</td>
      <td><select data-k="type">${optionList(STEP_TYPES.map((v) => ({ v })), "v", (x) => x.v, s.type)}</select></td>
      <td><select data-k="toolId">${optionList(tools, "id", (t) => "T" + t.toolNumber, s.toolId)}</select></td>
      <td><input data-k="spindleRpm" type="number" value="${esc(s.spindleRpm)}"></td>
      <td><input data-k="feedMmPerRev" type="number" step="0.01" value="${esc(s.feedMmPerRev)}"></td>
      <td><input data-k="depthOfCutMm" type="number" step="0.1" value="${esc(s.depthOfCutMm)}"></td>
      <td><input data-k="cuttingSpeedMmPerMin" type="number" step="0.1" value="${esc(s.cuttingSpeedMmPerMin)}"></td>
      <td><input data-k="finishAllowanceMm" type="number" step="0.1" value="${esc(s.finishAllowanceMm)}"></td>
      <td><input type="checkbox" data-k="enabled" ${s.enabled !== false ? "checked" : ""}></td>
      <td><button class="small danger" onclick="removeStep(this)">×</button></td>
    </tr>`;
  }

  window.removeStep = function (btn) {
    const tr = btn.closest("tr");
    tr.parentNode.removeChild(tr);
    renumberSteps();
  };

  function renumberSteps() {
    document.querySelectorAll("#steps-body tr").forEach((tr, i) => {
      tr.children[0].textContent = i + 1;
    });
  }

  window.addStep = function () {
    const tools = S.config.tools;
    if (!tools.length) { toast("请先在刀具库添加刀具", true); return; }
    const s = { type: "ROUGH_TURNING", toolId: tools[0].id, spindleRpm: 1200, feedMmPerRev: 0.2, depthOfCutMm: 2, cuttingSpeedMmPerMin: 150, finishAllowanceMm: 0, enabled: true };
    const body = $("steps-body");
    const wrap = document.createElement("tbody");
    wrap.innerHTML = stepRow(s, tools, body.children.length);
    body.appendChild(wrap.firstElementChild);
    renumberSteps();
  };

  function viewPlans(c) {
    const rows = c.plans.map((p) => `<tr>
      <td>${esc(p.name)}</td>
      <td>${esc((findById(c.parts, p.partId) || {}).name || p.partId)}</td>
      <td>φ${p.stockDiameterMm} × ${p.stockLengthMm} mm</td>
      <td>${(p.steps || []).length} 道</td>
      <td class="muted">${esc(p.description)}</td>
      <td class="actions"><button class="small" onclick="openPlan('${jsStr(p.id)}')">编辑</button>
        <button class="small danger" onclick="delEntity('plans','${jsStr(p.id)}','工艺方案')">删除</button></td>
    </tr>`);
    return `<div class="panel"><h3>工艺方案 <button class="primary small" onclick="openPlan('')">新增方案</button></h3>
      ${table(["名称", "零件", "毛坯", "工序", "说明", ""], rows, "尚未配置工艺方案")}</div>`;
  }

  window.openPlan = function (id) {
    const p = findById(S.config.plans, id) || {
      name: "", partId: (S.config.parts[0] || {}).id || "", stockDiameterMm: 100, stockLengthMm: 50, description: "",
      steps: []
    };
    openModal(id ? "编辑工艺方案" : "新增工艺方案", `
      <div class="form-row">
        <div class="field"><label>方案名称</label><input id="f_name" value="${esc(p.name)}"></div>
        <div class="field"><label>零件</label><select id="f_partId">${optionList(S.config.parts, "id", (x) => x.name, p.partId)}</select></div>
      </div>
      <div class="grid3">
        <div class="field"><label>毛坯直径 (mm)</label><input id="f_stockDiameterMm" type="number" step="0.1" value="${esc(p.stockDiameterMm)}"></div>
        <div class="field"><label>毛坯长度 (mm)</label><input id="f_stockLengthMm" type="number" step="0.1" value="${esc(p.stockLengthMm)}"></div>
        <div class="field"><label>说明</label><input id="f_description" value="${esc(p.description)}"></div>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin:16px 0 8px">
        <b style="font-size:13px">工序步骤</b><button class="small" onclick="addStep()">+ 添加工序</button>
      </div>
      <div class="steps-wrap"><table class="steps-table">
        <thead><tr><th>#</th><th>工序</th><th>刀具</th><th>转速</th><th>进给</th><th>切深</th><th>线速度</th><th>余量</th><th>启用</th><th></th></tr></thead>
        <tbody id="steps-body">${(p.steps || []).map((s, i) => stepRow(s, S.config.tools, i)).join("")}</tbody>
      </table></div>`,
      async () => {
        const steps = [];
        document.querySelectorAll("#steps-body tr").forEach((tr, i) => {
          const get = (k) => tr.querySelector(`[data-k="${k}"]`);
          steps.push({
            id: (p.steps && p.steps[i] && p.steps[i].id) || "",
            planId: id || "",
            orderIndex: i,
            type: get("type").value,
            toolId: get("toolId").value,
            cuttingSpeedMmPerMin: Number(get("cuttingSpeedMmPerMin").value),
            spindleRpm: Number(get("spindleRpm").value),
            feedMmPerRev: Number(get("feedMmPerRev").value),
            depthOfCutMm: Number(get("depthOfCutMm").value),
            finishAllowanceMm: Number(get("finishAllowanceMm").value),
            approachDistanceMm: 10, retractDistanceMm: 10, safetyDistanceMm: 10,
            enabled: get("enabled").checked, notes: ""
          });
        });
        await api("/api/v1/plans", { method: "POST", body: {
          id: id || "", name: $("f_name").value.trim(), partId: $("f_partId").value,
          stockDiameterMm: Number($("f_stockDiameterMm").value), stockLengthMm: Number($("f_stockLengthMm").value),
          description: $("f_description").value.trim(), steps
        } });
        toast("工艺方案已保存");
      });
  };

  // ===== 图纸 =====
  function viewDrawings(c) {
    const rows = c.drawings.map((d) => {
      const cor = correctionOf(d.id);
      return `<tr>
        <td>${esc(d.filename)}</td>
        <td>${d.layers} / ${d.entities}</td>
        <td class="muted">${d.dxfContent ? (d.dxfContent.length + " 字符") : "无内容（不可加工）"}</td>
        <td>${cor ? `×${cor.scale} / ${cor.unit}` : "未设置"}</td>
        <td class="actions">
          <button class="small" onclick="openDrawing('${jsStr(d.id)}')">编辑</button>
          <button class="small" onclick="openCorrection('${jsStr(d.id)}')">校正</button>
          <button class="small danger" onclick="delEntity('drawings','${jsStr(d.id)}','图纸')">删除</button>
        </td>
      </tr>`;
    });
    return `<div class="panel"><h3>图纸任务 <button class="primary small" onclick="openDrawing('')">新增图纸</button></h3>
      <div class="desc">图纸即平板端的“加工任务”。DXF 原文会同步到平板并缓存，离线也能继续加工。尺寸校正按图纸保存。</div>
      ${table(["文件名", "图层/实体", "DXF 内容", "校正", ""], rows, "尚未配置图纸")}</div>`;
  }

  window.openDrawing = function (id) {
    const d = findById(S.config.drawings, id) || { filename: "", layers: 0, entities: 0, source: "SERVER", dxfContent: "" };
    openModal(id ? "编辑图纸" : "新增图纸", `
      <div class="form-row">
        <div class="field"><label>文件名</label><input id="f_filename" value="${esc(d.filename)}"></div>
        <div class="field"><label>图层数</label><input id="f_layers" type="number" value="${esc(d.layers)}"></div>
        <div class="field"><label>实体数</label><input id="f_entities" type="number" value="${esc(d.entities)}"></div>
      </div>
      <div class="field" style="margin-bottom:10px"><label>从本机选择 .dxf 文件（会读取为文本）</label>
        <input id="f_file" type="file" accept=".dxf,text/plain"></div>
      <div class="field"><label>DXF 原文</label><textarea id="f_dxfContent" rows="12" placeholder="粘贴 DXF 文本，或选择文件自动填充">${esc(d.dxfContent)}</textarea></div>`,
      async () => {
        await api("/api/v1/drawings", { method: "POST", body: {
          id: id || "", filename: $("f_filename").value.trim(), layers: Number($("f_layers").value),
          entities: Number($("f_entities").value), source: d.source || "SERVER", dxfContent: $("f_dxfContent").value
        } });
        toast("图纸已保存");
      });
    $("f_file").addEventListener("change", (ev) => {
      const file = ev.target.files && ev.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        $("f_dxfContent").value = String(reader.result || "");
        if (!$("f_filename").value.trim()) $("f_filename").value = file.name;
        toast("已读取 " + file.name + "，请核对后保存");
      };
      reader.readAsText(file);
    });
  };

  window.openCorrection = function (drawingId) {
    const cor = correctionOf(drawingId) || { drawingId, scale: 1, offsetX: 0, offsetY: 0, rotationDeg: 0, mirrorX: false, mirrorY: false, unit: "MM" };
    openModal("图纸尺寸校正", `
      <div class="desc">平板端生成刀路前会自动套用此校正。适用于图纸单位/比例与实际工件不符的情况。</div>
      <div class="grid3">
        <div class="field"><label>缩放倍数</label><input id="f_scale" type="number" step="0.001" value="${esc(cor.scale)}"></div>
        <div class="field"><label>单位</label><select id="f_unit">${optionList(["MM", "INCH"].map((v) => ({ v })), "v", (x) => x.v, cor.unit)}</select></div>
        <div class="field"><label>旋转角度 (°)</label><input id="f_rotationDeg" type="number" step="0.1" value="${esc(cor.rotationDeg)}"></div>
      </div>
      <div class="grid2" style="margin-top:12px">
        <div class="field"><label>X 偏移 (mm)</label><input id="f_offsetX" type="number" step="0.1" value="${esc(cor.offsetX)}"></div>
        <div class="field"><label>Y 偏移 (mm)</label><input id="f_offsetY" type="number" step="0.1" value="${esc(cor.offsetY)}"></div>
      </div>
      <div class="form-row" style="margin-top:12px">
        <label class="check"><input type="checkbox" id="f_mirrorX" ${cor.mirrorX ? "checked" : ""}> X 镜像</label>
        <label class="check"><input type="checkbox" id="f_mirrorY" ${cor.mirrorY ? "checked" : ""}> Y 镜像</label>
      </div>`,
      async () => {
        await api("/api/v1/corrections", { method: "POST", body: {
          drawingId, scale: Number($("f_scale").value), offsetX: Number($("f_offsetX").value),
          offsetY: Number($("f_offsetY").value), rotationDeg: Number($("f_rotationDeg").value),
          mirrorX: $("f_mirrorX").checked, mirrorY: $("f_mirrorY").checked, unit: $("f_unit").value
        } });
        toast("尺寸校正已保存");
      });
  };

  // ===== 任务记录 =====
  function taskTable(list) {
    const rows = (list || []).map((t) => `<tr>
      <td>${esc(t.partName)}</td>
      <td class="mono">${esc(t.planId)}</td>
      <td>${tag(t.status, t.status === "SUCCESS")}</td>
      <td>${Number(t.durationSec).toFixed(1)} s</td>
      <td>${esc(t.operator)}</td>
      <td class="muted">${t.finishedAt ? new Date(t.finishedAt).toLocaleString() : "-"}</td>
    </tr>`);
    return table(["零件", "方案", "状态", "耗时", "操作员", "完成时间"], rows, "暂无任务记录");
  }

  function viewTasks() {
    return `<div class="panel"><h3>任务记录</h3>
      <div class="desc">由平板端在任务结束后自动上传；离线期间暂存本机，联网后补传。</div>
      ${taskTable(S.tasks)}</div>`;
  }

  // ===== 设备管理 =====
  const PERM_LABELS = [
    ["taskSelect", "任务选择"], ["previewStart", "预览下发"], ["monitor", "运行监控"],
    ["alarms", "报警状态"], ["advanced", "高级模式"], ["serverSync", "服务端同步"],
    ["drawings", "图纸管理"], ["cam", "CAM 刀路"], ["machining", "加工控制"],
    ["io", "IO 监控"], ["history", "任务历史"]
  ];

  function fmtTime(ts) {
    if (!ts) return "-";
    return new Date(ts).toLocaleString();
  }

  function onlineBadge(dev) {
    const online = !!dev.online;
    return `<span class="dot ${online ? "on" : "off"}" style="margin-right:6px"></span>${online ? "在线" : "离线"}`;
  }

  function permCheckboxes(id, perms) {
    return PERM_LABELS.map(([k, label]) => {
      const checked = perms[k] ? " checked" : "";
      return `<label class="perm-item"><input type="checkbox" data-perm="${k}"${checked}> ${esc(label)}</label>`;
    }).join("");
  }

  function viewDevices() {
    const rows = S.devices.map((d) => `
      <tr>
        <td><code>${esc(d.id)}</code></td>
        <td>${esc(d.unitName)}</td>
        <td>${esc(d.contactName)}</td>
        <td>${esc(d.phone)}</td>
        <td>${esc(d.serverAddress)}</td>
        <td>${onlineBadge(d)}</td>
        <td>${fmtTime(d.lastSeen)}</td>
        <td>
          <button class="small" onclick='editPermissions(${JSON.stringify(d.id)}, ${JSON.stringify(d.permissions)})'>权限</button>
        </td>
      </tr>`).join("");
    const table = rows
      ? `<table class="grid"><thead><tr><th>设备ID</th><th>单位</th><th>联系人</th><th>电话</th><th>服务器</th><th>状态</th><th>最近心跳</th><th>操作</th></tr></thead><tbody>${rows}</tbody></table>`
      : `<div class="desc">暂无注册设备。客户端首次启动完成注册后会出现在这里。</div>`;
    return `
      <div class="hint-box">客户端首次打开会先配置网络并注册（单位、姓名、电话、服务器地址）。注册后可在此查看在线状态，并按设备开关功能权限。默认全部权限开启。</div>
      <div class="panel"><h3>已注册设备</h3>${table}</div>
      <div class="panel"><h3>管理员密码
        <button class="small" onclick="changeAdminPassword()">修改</button>
      </h3>
      <div class="desc">客户端右上角「设置」按钮需输入此密码才能进入。默认 <code>admin123</code>，建议首次使用后修改。</div>
      </div>`;
  }

  window.editPermissions = function (id, perms) {
    openModal("功能权限", `<div class="perm-grid">${permCheckboxes(id, perms || {})}</div>`, async () => {
      const inputs = $("modal-body").querySelectorAll("input[data-perm]");
      const next = {};
      inputs.forEach((el) => { next[el.dataset.perm] = el.checked; });
      await api(`/api/v1/devices/${encodeURIComponent(id)}/permissions`, {
        method: "PUT", body: { permissions: next }
      });
      toast("权限已更新");
    });
  };

  window.changeAdminPassword = function () {
    openModal("修改管理员密码", `
      <label class="form-label">新密码</label>
      <input type="text" id="new-admin-pwd" class="input">
      <div class="desc">客户端下次联网校验时使用新密码。</div>`, async () => {
      const pwd = $("new-admin-pwd").value.trim();
      if (!pwd) throw new Error("密码不能为空");
      await api("/api/v1/admin-password", { method: "POST", body: { newPassword: pwd } });
      toast("管理员密码已更新");
    });
  };

  // ===== 删除 =====
  window.delEntity = async function (resource, id, label) {
    if (!confirm("确认删除该" + label + "？此操作会立即影响已同步的平板。")) return;
    try {
      await api("/api/v1/" + resource + "/" + encodeURIComponent(id), { method: "DELETE" });
      toast(label + "已删除");
      await loadAll();
    } catch (e) { toast(e.message, true); }
  };

  // ===== 弹窗 =====
  let modalSaveHandler = null;

  function openModal(title, bodyHtml, onSave) {
    $("modal-title").textContent = title;
    $("modal-body").innerHTML = bodyHtml;
    modalSaveHandler = onSave;
    $("modal-mask").classList.add("show");
  }

  function closeModal() {
    $("modal-mask").classList.remove("show");
    modalSaveHandler = null;
  }

  $("modal-close").onclick = closeModal;
  $("modal-cancel").onclick = closeModal;
  $("modal-save").onclick = async () => {
    if (!modalSaveHandler) return;
    const btn = $("modal-save");
    btn.disabled = true;
    try {
      await modalSaveHandler();
      closeModal();
      await loadAll();
    } catch (e) {
      toast(e.message, true);
    } finally {
      btn.disabled = false;
    }
  };

  // ===== WebSocket =====
  function connectWs() {
    if (S.ws) { try { S.ws.close(); } catch (_) {} }
    const proto = location.protocol === "https:" ? "wss" : "ws";
    const ws = new WebSocket(`${proto}://${location.host}/ws/status?token=${encodeURIComponent(S.token)}`);
    S.ws = ws;
    setWsBadge(false);
    ws.onopen = () => setWsBadge(true);
    ws.onclose = () => setWsBadge(false);
    ws.onerror = () => setWsBadge(false);
    ws.onmessage = (ev) => {
      try {
        S.status = JSON.parse(ev.data);
        if (S.tab === "overview") {
          const area = $("live-area");
          if (area) area.innerHTML = liveStatusHtml();
        }
      } catch (_) {}
    };
  }

  function setWsBadge(on) {
    $("ws-dot").className = "dot " + (on ? "on" : "off");
    $("ws-text").textContent = on ? "状态流已连接" : "状态流未连接";
  }

  // ===== 事件 =====
  $("login-btn").onclick = login;
  $("token").addEventListener("keydown", (e) => { if (e.key === "Enter") login(); });
  $("refresh-btn").onclick = async () => {
    try { await loadAll(); toast("已刷新"); } catch (e) { toast(e.message, true); }
  };
  $("token-btn").onclick = () => {
    const t = prompt("输入新的管理口令（需与服务器 CNC_ADMIN_TOKEN 一致）", "");
    if (!t) return;
    S.token = t.trim();
    localStorage.setItem("cnc_token", S.token);
    loadAll().then(connectWs).catch((e) => toast(e.message, true));
  };

  // 启动
  (async function boot() {
    try {
      const status = await api("/api/v1/status");
      S.status = status;
    } catch (_) {}
    if (S.token) {
      try {
        await api("/api/v1/auth/check");
        $("login").style.display = "none";
        $("app").style.display = "block";
        await loadAll();
        connectWs();
        return;
      } catch (_) {}
    }
    logout("");
  })();
})();
